import PhotoSelectorDashboard from '@/components/photo-selector/dashboard'

export default function Home() {
  return <PhotoSelectorDashboard />
}
