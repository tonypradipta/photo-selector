import { createClient } from '@/lib/supabase/server'

export async function getProjects() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return []
  const { data } = await supabase.from('projects').select('id,name,client_name,status,client_token,created_at,updated_at').eq('owner_id', user.id).order('created_at', { ascending: false })
  return data ?? []
}
